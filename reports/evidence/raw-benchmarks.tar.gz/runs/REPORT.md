# ByteGuard benchmark comparisons (measurement schema v3)

Only completed v3 runs are included. Run tags, implementation fingerprints,
kernel, duration, workload hashes and rate settings separate distinct groups.
Different random seeds are counted as repeated trials within one group.

**Latency is for answered DNS queries only.** Host CPU includes the
traffic generators. These are not filter-only CPU-cycle measurements.
Interface PPS is input traffic, not verified DNS-server capacity.
The synchronized launcher does not guarantee identical first-packet timing.

| Tag | Mode | Scenario | Legit QPS | Attack PPS | Trials | Success | Mean latency (ms) | dnsmasq CPU (% core) | RX PPS | RX Mbps | Build/config |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| before-tuning | nft | distributed | 50 | 3000 | 2 | 44.10% | 0.155 | 0.10 | 3023.8 | 1.86 | {"global_bur |
| before-tuning | nft | none | 50 | 0 | 2 | 100.00% | 0.226 | 0.30 | 50.7 | 0.03 | {"global_bur |
| before-tuning | none | distributed | 50 | 3000 | 2 | 100.00% | 0.138 | 0.20 | 3025.8 | 1.86 | no-filter |
| before-tuning | none | none | 50 | 0 | 2 | 100.00% | 0.200 | 0.30 | 50.6 | 0.03 | no-filter |
| before-tuning | xdp | distributed | 50 | 3000 | 3 | 2.73% | 0.154 | 0.00 | 3020.5 | 1.52 | 1bfa75d16a9d |
| before-tuning | xdp | none | 50 | 0 | 2 | 100.00% | 0.222 | 0.35 | 50.3 | 0.02 | 1bfa75d16a9d |

Full per-run settings and measurements: `summary.csv`.
Matched-group means and sample standard deviations: `grouped.csv`.
