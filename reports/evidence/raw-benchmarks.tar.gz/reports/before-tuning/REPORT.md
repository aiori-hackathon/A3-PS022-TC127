# ByteGuard benchmark comparisons (measurement schema v3)

Only completed v4 runs are included. Run tags, implementation fingerprints,
kernel, duration, workload hashes and rate settings separate distinct groups.
Different random seeds are counted as repeated trials within one group.
Packet-capture-enabled debug runs are grouped separately from clean performance runs.

**Latency is for answered DNS queries only.** Host CPU includes the
traffic generators. These are not filter-only CPU-cycle measurements.
Interface PPS is input traffic, not verified DNS-server capacity.
The synchronized launcher does not guarantee identical first-packet timing.

| Tag | Mode | Scenario | Legit QPS | Attack PPS | Trials | Success | Mean latency (ms) | dnsmasq CPU (% core) | RX PPS | RX Mbps | Build/config |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| before-tuning | nft | distributed | 50 | 3000 | 2 | 45.90% | 0.160 | 0.05 | 3020.9 | 1.86 | {"global_bur |
| before-tuning | nft | none | 50 | 0 | 2 | 100.00% | 0.227 | 0.35 | 50.7 | 0.03 | {"global_bur |
| before-tuning | none | distributed | 50 | 3000 | 2 | 100.00% | 0.146 | 0.25 | 3024.5 | 1.86 | no-filter |
| before-tuning | none | none | 50 | 0 | 2 | 100.00% | 0.235 | 0.35 | 50.7 | 0.03 | no-filter |
| before-tuning | xdp | distributed | 50 | 3000 | 2 | 44.10% | 0.186 | 0.05 | 3021.6 | 1.52 | 1bfa75d16a9d |
| before-tuning | xdp | none | 50 | 0 | 2 | 100.00% | 0.242 | 0.40 | 50.4 | 0.02 | 1bfa75d16a9d |

Full per-run settings and measurements: `summary.csv`.
Matched-group means and sample standard deviations: `grouped.csv`.
